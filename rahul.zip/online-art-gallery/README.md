# Online Art Gallery - Student Project

A lightweight React + Redux demo app for showcasing artworks.  
Pages included: Home, Gallery, About, Contact, Sign In, Sign Up.

## How to run (in VS Code)
1. Extract this folder.
2. Open the folder in VS Code.
3. In a terminal run:
   ```bash
   npm install
   npm start
   ```
4. The app uses react-router and redux. All data is local and demo-only.

## What to showcase in your recording
- Home page hero + featured artworks
- Gallery browsing and selecting an artwork
- Sign in / sign up forms (demo)
- Contact form submission (client-side demo)
- Briefly explain the Redux store (`src/store.js`) and slices in `src/slices`

Good luck on your project demo! Customize artworks and styling as you like.
