import { createSlice } from '@reduxjs/toolkit';
const initialState = {
  artworks: [
    { id: 1, title: 'Sunset Over City', artist: 'A. Kumar', price: 250, img: '/images/art1.svg' },
    { id: 2, title: 'Blue Abstraction', artist: 'L. Rao', price: 400, img: '/images/art2.svg' },
    { id: 3, title: 'Quiet Lake', artist: 'M. Patel', price: 320, img: '/images/art3.svg' }
  ],
  selected: null
};
const gallerySlice = createSlice({
  name: 'gallery',
  initialState,
  reducers: {
    addArtwork(state, action) {
      state.artworks.push(action.payload);
    },
    selectArtwork(state, action) {
      state.selected = action.payload;
    },
    clearSelection(state) {
      state.selected = null;
    }
  }
});
export const { addArtwork, selectArtwork, clearSelection } = gallerySlice.actions;
export default gallerySlice.reducer;
