import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  user: null,
  token: null,
  status: 'idle',
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    signinSuccess(state, action) {
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.status = 'signedin';
    },
    signout(state) {
      state.user = null;
      state.token = null;
      state.status = 'signedout';
    }
  }
});

export const { signinSuccess, signout } = authSlice.actions;
export default authSlice.reducer;
