import React from 'react';
import { NavLink } from 'react-router-dom';
export default function Navbar(){
  return (
    <nav className="nav">
      <div className="brand">Online Art Gallery</div>
      <div>
        <NavLink to="/">Home</NavLink>
        <NavLink to="/gallery" style={{marginLeft:12}}>Gallery</NavLink>
        <NavLink to="/about" style={{marginLeft:12}}>About</NavLink>
        <NavLink to="/contact" style={{marginLeft:12}}>Contact</NavLink>
        <NavLink to="/signin" style={{marginLeft:12}}>Sign In</NavLink>
        <NavLink to="/signup" style={{marginLeft:12}}>Sign Up</NavLink>
      </div>
    </nav>
  );
}
