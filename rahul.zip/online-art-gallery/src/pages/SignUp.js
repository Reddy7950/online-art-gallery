import React from 'react';
export default function SignUp(){
  return (
    <div>
      <h2>Sign Up</h2>
      <form className="form card" onSubmit={e=>{e.preventDefault();alert('Signed up (demo)')}}>
        <input className="input" placeholder="Full name" />
        <input className="input" placeholder="Email" />
        <input className="input" placeholder="Password" type="password" />
        <button className="btn" type="submit">Create Account</button>
      </form>
    </div>
  );
}
