import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { signinSuccess } from '../slices/authSlice';
export default function SignIn(){
  const [email,setEmail]=useState('');
  const dispatch = useDispatch();
  function handle(e){
    e.preventDefault();
    // demo signin - replace with real auth
    dispatch(signinSuccess({user:{email}, token:'demo-token'}));
    alert('Signed in (demo). Now you can record this action for project.');
  }
  return (
    <div>
      <h2>Sign In</h2>
      <form className="form card" onSubmit={handle}>
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" />
        <button className="btn" type="submit">Sign In</button>
      </form>
    </div>
  );
}
