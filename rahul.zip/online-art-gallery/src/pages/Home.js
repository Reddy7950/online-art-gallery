import React from 'react';
import { Link } from 'react-router-dom';
export default function Home(){
  return (
    <div>
      <section className="hero card">
        <div>
          <h1>Welcome to the Online Art Gallery</h1>
          <p className="muted">Explore curated artworks, read cultural history, take virtual tours and support artists.</p>
          <Link to="/gallery" className="btn" style={{marginTop:12}}>Visit Gallery</Link>
        </div>
        <div style={{flex:1,textAlign:'right'}}>
          <img src="/images/hero.svg" alt="hero" style={{maxWidth:260}}/>
        </div>
      </section>

      <section style={{marginTop:18}}>
        <h2>Featured Collections</h2>
        <div className="gallery-grid">
          <div className="artwork card">
            <img src="/images/art1.svg" alt="art1" style={{width:'100%',borderRadius:8}}/>
            <div className="art-info"><strong>Sunset Over City</strong><div className="muted">A. Kumar • ₹250</div></div>
          </div>
          <div className="artwork card">
            <img src="/images/art2.svg" alt="art2" style={{width:'100%',borderRadius:8}}/>
            <div className="art-info"><strong>Blue Abstraction</strong><div className="muted">L. Rao • ₹400</div></div>
          </div>
          <div className="artwork card">
            <img src="/images/art3.svg" alt="art3" style={{width:'100%',borderRadius:8}}/>
            <div className="art-info"><strong>Quiet Lake</strong><div className="muted">M. Patel • ₹320</div></div>
          </div>
        </div>
      </section>
    </div>
  );
}
