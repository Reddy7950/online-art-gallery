import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectArtwork } from '../slices/gallerySlice';
export default function Gallery(){
  const artworks = useSelector(s => s.gallery.artworks);
  const dispatch = useDispatch();
  return (
    <div>
      <h2>Gallery</h2>
      <p>Browse artworks — click any to view details.</p>
      <div className="gallery-grid">
        {artworks.map(a => (
          <div key={a.id} className="artwork card" onClick={() => dispatch(selectArtwork(a))} style={{cursor:'pointer'}}>
            <img src={a.img} alt={a.title} style={{width:'100%',borderRadius:8}}/>
            <div className="art-info"><strong>{a.title}</strong><div className="muted">{a.artist} • ₹{a.price}</div></div>
          </div>
        ))}
      </div>
    </div>
  );
}
