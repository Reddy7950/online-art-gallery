import React from 'react';
export default function Contact(){
  return (
    <div>
      <h2>Contact</h2>
      <p>If you'd like to partner or showcase, send us a message.</p>
      <form className="form card" onSubmit={(e)=>{e.preventDefault();alert('Message sent (demo)')}}>
        <input className="input" placeholder="Your name" />
        <input className="input" placeholder="Your email" />
        <textarea className="input" placeholder="Message" rows="6" />
        <button className="btn" type="submit">Send Message</button>
      </form>
    </div>
  );
}
