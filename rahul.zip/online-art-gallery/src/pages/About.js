import React from 'react';
export default function About(){
  return (
    <div>
      <h2>About the Gallery</h2>
      <p>This platform showcases artworks and provides cultural history and virtual tours for an engaging visitor experience. Built as a student project demo.</p>
      <h3>Curatorial Vision</h3>
      <p>We feature diverse artists and provide easy ways for visitors to learn and purchase art.</p>
    </div>
  );
}
